#include <iostream>

using namespace std;

void say()
{
    cout << "Hello" << endl;
}